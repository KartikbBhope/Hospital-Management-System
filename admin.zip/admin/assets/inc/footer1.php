<footer class="footer footer-alt">
   
</footer>